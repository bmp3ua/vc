jQuery(document).ready(function($){
	
	$('#sl_icons_upload').on('click', function(e) {
		e.preventDefault();
		var icons_loader = wp.media({
            frame:   $(this).data.frame,			
			title: 'Upload Icons Set',
			multiple: false
		})
		icons_loader.on('select update insert', function(e){
			var state = icons_loader.state(), selection = state.get('selection').first().toJSON();
			$.ajax({ 
				type : 'POST',
				url : ajaxurl,
				data : { action : 'sl_add_zipped_font', values : selection },
				cache : false,
				complete : function(data) {
				},
				success : function(data) {	
				    if ( data.match(/Error/) ) alert(data);
                    else location.reload(); 				
				}
			});           
		});	
	    icons_loader.open();
	});
	
	$('.remove_mega_icons_set').on('click', function(e) {
		$.ajax({ 
			type : 'POST',
			url : ajaxurl,
			data : { action : 'sl_remove_zipped_font', font : $(e.target).attr('data-delete') },
			cache : false,
			complete : function(data) {
				location.reload(); 
			},
			success : function(data) {					
			}
		});		
	});
	
	
    function js_searcher() {
		var icon_search_process = false;
		
		$('#sl_admin_icons_search input, #item_icons_manager #icon_search').on('keyup', function(e) {
			if (!icon_search_process) { 
				var needle = $(e.target).val(), j;
				icon_search_process = true;
				$('.sl_icons_block, [id*="-icons_table"').each(function(i, el) {
					j = 0;
					$(el).find('span i').each(function(i, el) {
						var rgxp = new RegExp(needle);
						if ($(el).attr('class').match(rgxp)) { $(el).parent().css({ display : 'inline-block' }); j++; }
						else $(el).parent().css({display : 'none'});
					});
					$(el).find('.icons-count').html(j + ' icons');
				});
				icon_search_process = false;
			}
		});
    }		
	
	js_searcher();
	
});