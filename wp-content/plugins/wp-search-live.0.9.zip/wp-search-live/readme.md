# WP Search

WordPress search plugin that uses the REST API, Backbone, and Underscore. This doesn't require pressing enter or refreshing the page, and results are shown instantaneously.

![alt text](https://s3.amazonaws.com/f.cl.ly/items/1x0b1t421J2e0z2d1U30/Screen%20Recording%202015-06-11%20at%2003.38%20PM.gif "What it does")

## Requirements

WP REST API Plugin